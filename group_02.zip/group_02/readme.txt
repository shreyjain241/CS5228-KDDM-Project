Group 02

Members:
Shrey Jain (e0267621)
Manasa Kashyap (e0267773)
Rahul Soni (e0210447)

Running Instructions:

1) add files train_v2.csv and test_v2.csv to data/ folder
2) run with command : python run.py
3) submission file is outputed to the results/ folder as xgboost_submission_<accuracy>.csv